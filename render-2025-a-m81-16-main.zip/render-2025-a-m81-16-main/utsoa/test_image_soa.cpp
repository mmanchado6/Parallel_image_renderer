#include "../soa/include/image_soa.hpp"
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <sstream>
#include <string>
#include <tuple>

using image::imageSOA;

TEST(ImageSOATest, DefaultPixelsAreBlack) {
  imageSOA const img(4, 3);
  for (int y = 0; y < 3; ++y) {
    for (int x = 0; x < 4; ++x) {
      EXPECT_EQ(img.red(y, x), 0);
      EXPECT_EQ(img.green(y, x), 0);
      EXPECT_EQ(img.blue(y, x), 0);
    }
  }
}

TEST(ImageSOATest, SetAndGetPixel) {
  imageSOA img(2, 2);
  img.setPixel(0, 0, std::make_tuple(10, 20, 30));
  img.setPixel(1, 1, std::make_tuple(101, 102, 103));

  EXPECT_EQ(img.red(0, 0), 10);
  EXPECT_EQ(img.green(0, 0), 20);
  EXPECT_EQ(img.blue(0, 0), 30);

  EXPECT_EQ(img.red(0, 1), 0);
  EXPECT_EQ(img.green(0, 1), 0);
  EXPECT_EQ(img.blue(0, 1), 0);

  EXPECT_EQ(img.red(1, 0), 0);
  EXPECT_EQ(img.green(1, 0), 0);
  EXPECT_EQ(img.blue(1, 0), 0);

  EXPECT_EQ(img.red(1, 1), 101);
  EXPECT_EQ(img.green(1, 1), 102);
  EXPECT_EQ(img.blue(1, 1), 103);
}

TEST(ImageSOATest, WritePPMProducesExpectedContent) {
  int const width  = 3;
  int const height = 2;
  imageSOA img(width, height);

  // Fill with distinct, predictable values
  for (int y = 0; y < height; ++y) {
    for (int x = 0; x < width; ++x) {
      int const base = y * 10 + x;
      img.setPixel(y, x, std::make_tuple(base, base + 1, base + 2));
    }
  }

  // Write to a temporary file
  std::string const filename = "test_output.ppm";
  img.write_ppm(filename);

  // Read back the file and verify its contents
  std::ifstream file(filename);
  ASSERT_TRUE(file.is_open()) << "Failed to open output PPM file.";

  std::stringstream buffer;
  buffer << file.rdbuf();
  std::string const expected_content =
      "P3\n3 2\n255\n0 1 2\n1 2 3\n2 3 4\n10 11 12\n11 12 13\n12 13 14\n";

  EXPECT_EQ(buffer.str(), expected_content);

  // Clean up
  file.close();

  EXPECT_TRUE(std::filesystem::remove(filename)) << "Failed to delete temporary file: " << filename;
}

// Test set and get red, green, blue individually
TEST(ImageSOATest, SetAndGetIndividualColors) {
  imageSOA img(2, 2);
  img.setRed(0, 0, 50);
  img.setGreen(0, 0, 100);
  img.setBlue(0, 0, 150);

  EXPECT_EQ(img.red(0, 0), 50);
  EXPECT_EQ(img.green(0, 0), 100);
  EXPECT_EQ(img.blue(0, 0), 150);
}

// Test write ppm with individual color setting
TEST(ImageSOATest, WritePPMWithIndividualColors) {
  int const width  = 2;
  int const height = 2;
  imageSOA img(width, height);

  img.setRed(0, 0, 50);
  img.setGreen(0, 0, 100);
  img.setBlue(0, 0, 150);

  std::string const filename = "test_output.ppm";
  img.write_ppm(filename);

  std::ifstream file(filename);
  ASSERT_TRUE(file.is_open()) << "Failed to open output PPM file.";

  std::stringstream buffer;
  buffer << file.rdbuf();
  std::string const expected_content = "P3\n2 2\n255\n50 100 150\n0 0 0\n0 0 0\n0 0 0\n";

  EXPECT_EQ(buffer.str(), expected_content);

  file.close();
  EXPECT_TRUE(std::filesystem::remove(filename)) << "Failed to delete temporary file: " << filename;
}
