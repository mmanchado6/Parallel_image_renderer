#include "../aos/include/image_aos.hpp"
#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <sstream>
#include <string>
#include <system_error>
#include <tuple>

using image::imageAOS;

TEST(ImageAOSTest, DefaultPixelsAreBlack) {
  imageAOS const img(4, 3);
  for (int y = 0; y < 3; ++y) {
    for (int x = 0; x < 4; ++x) {
      auto [r, g, b] = img.pixel(y, x);
      EXPECT_EQ(r, 0);
      EXPECT_EQ(g, 0);
      EXPECT_EQ(b, 0);
    }
  }
}

TEST(ImageAOSTest, SetAndGetPixel) {
  imageAOS img(2, 2);
  img.setPixel(0, 0, std::make_tuple(10, 20, 30));
  img.setPixel(1, 1, std::make_tuple(101, 102, 103));

  auto [r00, g00, b00] = img.pixel(0, 0);
  EXPECT_EQ(r00, 10);
  EXPECT_EQ(g00, 20);
  EXPECT_EQ(b00, 30);

  auto [r01, g01, b01] = img.pixel(0, 1);
  EXPECT_EQ(r01, 0);
  EXPECT_EQ(g01, 0);
  EXPECT_EQ(b01, 0);

  auto [r10, g10, b10] = img.pixel(1, 0);
  EXPECT_EQ(r10, 0);
  EXPECT_EQ(g10, 0);
  EXPECT_EQ(b10, 0);

  auto [r11, g11, b11] = img.pixel(1, 1);
  EXPECT_EQ(r11, 101);
  EXPECT_EQ(g11, 102);
  EXPECT_EQ(b11, 103);
}

TEST(ImageAOSTest, WritePPMProducesExpectedContent) {
  int const width  = 3;
  int const height = 2;
  imageAOS img(width, height);

  // Fill with distinct, predictable values
  for (int y = 0; y < height; ++y) {
    for (int x = 0; x < width; ++x) {
      int const base = y * 10 + x;
      img.setPixel(y, x, std::make_tuple(base, base + 1, base + 2));
    }
  }

  auto tmp                   = std::filesystem::temp_directory_path() / "test_image_aos_output.ppm";
  std::string const filename = tmp.string();

  // Write and read back
  img.write_ppm(filename);
  std::ifstream ifs(filename);
  ASSERT_TRUE(ifs.is_open());

  std::ostringstream ss;
  ss << ifs.rdbuf();
  std::string const content = ss.str();

  // Build expected content
  std::ostringstream expect;
  expect << "P3\n" << width << " " << height << "\n255\n";
  for (int y = 0; y < height; ++y) {
    for (int x = 0; x < width; ++x) {
      int const base = y * 10 + x;
      expect << base << " " << (base + 1) << " " << (base + 2) << "\n";
    }
  }

  EXPECT_EQ(content, expect.str());

  // Cleanup
  std::error_code ec;
  std::filesystem::remove(tmp, ec);
}
