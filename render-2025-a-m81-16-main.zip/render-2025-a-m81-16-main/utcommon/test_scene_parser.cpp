#include "../include/scene.hpp"
#include "../include/scene_parser.hpp"
#include <cmath>
#include <gtest/gtest.h>
#include <stdexcept>

// Test procesar línea
TEST(test_process_line_scene, valid_line) {
  render::scene scene;
  EXPECT_NO_THROW(sceneParser::process_line("", scene));
  EXPECT_THROW(sceneParser::process_line("invalid_key: 123", scene), std::invalid_argument);
}

// Test parsear esfera
TEST(test_parse_sphere, valid_values) {
  render::scene scene;
  scene.add_material(
      material::material("mat1", material::material::materialType::Matte, {0.5, 0.5, 0.5}));
  EXPECT_NO_THROW(sceneParser::parse_sphere("sphere: 0 0 0 0.65 mat1", scene));
}

TEST(test_parse_sphere, invalid_values) {
  render::scene scene;
  EXPECT_THROW(sceneParser::parse_sphere("sphere: 0.0 0.0 0.0 1.0", scene), std::invalid_argument);
  EXPECT_THROW(sceneParser::parse_sphere("sphere: 0.0 0.0 0.0", scene), std::invalid_argument);
}

// Test parsear cilindro
TEST(test_parse_cylinder, valid_values) {
  render::scene scene;
  scene.add_material(material::material("test_material", material::material::materialType::Matte,
                                        {0.5, 0.5, 0.5}));
  EXPECT_NO_THROW(
      sceneParser::parse_cylinder("cylinder: 0.0 0.0 0.0 1.0 2.0 0.0 1.0 test_material", scene));
}

TEST(test_parse_cylinder, invalid_values) {
  render::scene scene;
  EXPECT_THROW(sceneParser::parse_cylinder("cylinder: 0.0 0.0 0.0 1.0 2.0 0.0", scene),
               std::invalid_argument);
  EXPECT_THROW(sceneParser::parse_cylinder("cylinder: 0.0 0.0 0.0", scene), std::invalid_argument);
}

// Test parsear material
TEST(test_parse_material, valid_matte) {
  render::scene scene;
  EXPECT_NO_THROW(sceneParser::parse_material("matte: test_material 0.5 0.5 0.5", scene));
}

TEST(test_parse_material, valid_metal) {
  render::scene scene;
  EXPECT_NO_THROW(sceneParser::parse_material("metal: test_material 0.5 0.5 0.5 0.1", scene));
}

TEST(test_parse_material, valid_refractive) {
  render::scene scene;
  EXPECT_NO_THROW(sceneParser::parse_material("refractive: test_material 1.5", scene));
}

TEST(test_parse_material, invalid_values) {
  render::scene scene;
  EXPECT_THROW(sceneParser::parse_material("matte: test_material 0.5 0.5", scene),
               std::invalid_argument);
  EXPECT_THROW(sceneParser::parse_material("metal: test_material 0.5 0.5", scene),
               std::invalid_argument);
  EXPECT_THROW(sceneParser::parse_material("refractive: test_material 0.5 0.5", scene),
               std::invalid_argument);
}
