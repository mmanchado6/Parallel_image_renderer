#include "../include/configuration_parser.hpp"
#include "../include/image.hpp"
#include <cmath>
#include <gtest/gtest.h>
#include <stdexcept>

// Test procesar línea
TEST(test_process_line, valid_line) {
  imagec::imageConfig cfg;
  EXPECT_NO_THROW(configurationParser::process_line("", cfg));
  EXPECT_THROW(configurationParser::process_line("invalid_key: 123", cfg), std::invalid_argument);
}

// Test parsear aspect ratio
TEST(test_parse_aspect_ratio, valid_values) {
  imagec::imageConfig cfg;
  EXPECT_NO_THROW(configurationParser::parse_aspect_ratio("aspect_ratio: 16 9", cfg));
}

TEST(test_parse_aspect_ratio, invalid_values) {
  imagec::imageConfig cfg;
  EXPECT_THROW(configurationParser::parse_aspect_ratio("aspect_ratio: 16", cfg),
               std::invalid_argument);
  EXPECT_THROW(configurationParser::parse_aspect_ratio("aspect_ratio: 16 9 extra", cfg),
               std::invalid_argument);
}

// Test parsear width
TEST(test_parse_width, valid_value) {
  imagec::imageConfig cfg;
  EXPECT_NO_THROW(configurationParser::parse_width("width: 1920", cfg));
}

TEST(test_parse_width, invalid_values) {
  imagec::imageConfig cfg;
  EXPECT_THROW(configurationParser::parse_width("width:", cfg), std::invalid_argument);
  EXPECT_THROW(configurationParser::parse_width("width: 1920 extra", cfg), std::invalid_argument);
}

// Test parsear gamma
TEST(test_parse_gamma, valid_value) {
  imagec::imageConfig cfg;
  EXPECT_NO_THROW(configurationParser::parse_gamma("gamma: 2.2", cfg));
}

TEST(test_parse_gamma, invalid_values) {
  imagec::imageConfig cfg;
  EXPECT_THROW(configurationParser::parse_gamma("gamma:", cfg), std::invalid_argument);
  EXPECT_THROW(configurationParser::parse_gamma("gamma: 2.2 extra", cfg), std::invalid_argument);
}

// Test parsear camera position
TEST(test_parse_camera_position, valid_values) {
  imagec::imageConfig cfg;
  EXPECT_NO_THROW(
      configurationParser::parse_camera_position("camera_position: 0.0 0.0 -10.0", cfg));
}

TEST(test_parse_camera_position, invalid_values) {
  imagec::imageConfig cfg;
  EXPECT_THROW(configurationParser::parse_camera_position("camera_position: 0.0 0.0", cfg),
               std::invalid_argument);
  EXPECT_THROW(
      configurationParser::parse_camera_position("camera_position: 0.0 0.0 -10.0 extra", cfg),
      std::invalid_argument);
}

// Test parsear camera target
TEST(test_parse_camera_target, valid_values) {
  imagec::imageConfig cfg;
  EXPECT_NO_THROW(configurationParser::parse_camera_target("camera_target: 0.0 0.0 0.0", cfg));
}

TEST(test_parse_camera_target, invalid_values) {
  imagec::imageConfig cfg;
  EXPECT_THROW(configurationParser::parse_camera_target("camera_target: 0.0 0.0", cfg),
               std::invalid_argument);
  EXPECT_THROW(configurationParser::parse_camera_target("camera_target: 0.0 0.0 0.0 extra", cfg),
               std::invalid_argument);
}

// Test parsear camera north
TEST(test_parse_camera_north, valid_values) {
  imagec::imageConfig cfg;
  EXPECT_NO_THROW(configurationParser::parse_camera_north("camera_north: 0.0 1.0 0.0", cfg));
}

TEST(test_parse_camera_north, invalid_values) {
  imagec::imageConfig cfg;
  EXPECT_THROW(configurationParser::parse_camera_north("camera_north: 0.0 1.0", cfg),
               std::invalid_argument);
  EXPECT_THROW(configurationParser::parse_camera_north("camera_north: 0.0 1.0 0.0 extra", cfg),
               std::invalid_argument);
}

// Test parsear field of view
TEST(test_parse_field_of_view, valid_value) {
  imagec::imageConfig cfg;
  EXPECT_NO_THROW(configurationParser::parse_field_of_view("field_of_view: 90", cfg));
}

TEST(test_parse_field_of_view, invalid_values) {
  imagec::imageConfig cfg;
  EXPECT_THROW(configurationParser::parse_field_of_view("field_of_view:", cfg),
               std::invalid_argument);
  EXPECT_THROW(configurationParser::parse_field_of_view("field_of_view: 90 extra", cfg),
               std::invalid_argument);
}

// Test parsear samples per pixel
TEST(test_parse_samples_per_pixel, valid_value) {
  imagec::imageConfig cfg;
  EXPECT_NO_THROW(configurationParser::parse_samples_per_pixel("samples_per_pixel: 100", cfg));
}

TEST(test_parse_samples_per_pixel, invalid_values) {
  imagec::imageConfig cfg;
  EXPECT_THROW(configurationParser::parse_samples_per_pixel("samples_per_pixel:", cfg),
               std::invalid_argument);
  EXPECT_THROW(configurationParser::parse_samples_per_pixel("samples_per_pixel: 100 extra", cfg),
               std::invalid_argument);
}

// Test parsear max depth
TEST(test_parse_max_depth, valid_value) {
  imagec::imageConfig cfg;
  EXPECT_NO_THROW(configurationParser::parse_max_depth("max_depth: 5", cfg));
}

TEST(test_parse_max_depth, invalid_values) {
  imagec::imageConfig cfg;
  EXPECT_THROW(configurationParser::parse_max_depth("max_depth:", cfg), std::invalid_argument);
  EXPECT_THROW(configurationParser::parse_max_depth("max_depth: 5 extra", cfg),
               std::invalid_argument);
}

// Test parsear material rng seed
TEST(test_parse_material_rng_seed, valid_value) {
  imagec::imageConfig cfg;
  EXPECT_NO_THROW(configurationParser::parse_material_rng_seed("material_rng_seed: 42", cfg));
}

TEST(test_parse_material_rng_seed, invalid_values) {
  imagec::imageConfig cfg;
  EXPECT_THROW(configurationParser::parse_material_rng_seed("material_rng_seed:", cfg),
               std::invalid_argument);
  EXPECT_THROW(configurationParser::parse_material_rng_seed("material_rng_seed: 42 extra", cfg),
               std::invalid_argument);
}

// Test parsear ray rng seed
TEST(test_parse_ray_rng_seed, valid_value) {
  imagec::imageConfig cfg;
  EXPECT_NO_THROW(configurationParser::parse_ray_rng_seed("ray_rng_seed: 84", cfg));
}

TEST(test_parse_ray_rng_seed, invalid_values) {
  imagec::imageConfig cfg;
  EXPECT_THROW(configurationParser::parse_ray_rng_seed("ray_rng_seed:", cfg),
               std::invalid_argument);
  EXPECT_THROW(configurationParser::parse_ray_rng_seed("ray_rng_seed: 84 extra", cfg),
               std::invalid_argument);
}

// Test parsear background dark color
TEST(test_parse_background_dark_color, valid_values) {
  imagec::imageConfig cfg;
  EXPECT_NO_THROW(
      configurationParser::parse_background_dark_color("background_dark_color: 0.1 0.2 0.3", cfg));
}

TEST(test_parse_background_dark_color, invalid_values) {
  imagec::imageConfig cfg;
  EXPECT_THROW(
      configurationParser::parse_background_dark_color("background_dark_color: 0.1 0.2", cfg),
      std::invalid_argument);
  EXPECT_THROW(configurationParser::parse_background_dark_color(
                   "background_dark_color: 0.1 0.2 0.3 extra", cfg),
               std::invalid_argument);
}

// Test parsear background light color
TEST(test_parse_background_light_color, valid_values) {
  imagec::imageConfig cfg;
  EXPECT_NO_THROW(configurationParser::parse_background_light_color(
      "background_light_color: 0.8 0.9 1.0", cfg));
}

TEST(test_parse_background_light_color, invalid_values) {
  imagec::imageConfig cfg;
  EXPECT_THROW(
      configurationParser::parse_background_light_color("background_light_color: 0.8 0.9", cfg),
      std::invalid_argument);
  EXPECT_THROW(configurationParser::parse_background_light_color(
                   "background_light_color: 0.8 0.9 1.0 extra", cfg),
               std::invalid_argument);
}
