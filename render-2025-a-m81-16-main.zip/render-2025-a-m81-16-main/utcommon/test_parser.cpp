#include "../include/parser.hpp"
#include <cmath>
#include <cstdio>
#include <gtest/gtest.h>
#include <print>
#include <string>
#include <vector>

// Test split_line
TEST(ParserTest, SplitLineBasic) {
  std::string const line = "  this is   a test  ";
  auto tokens            = parser::split_line(line);
  for (auto const & tok : tokens) {
    std::print("[{}] ", tok);
  }

  std::vector<std::string> const expected = {"this", "is", "a", "test"};
  EXPECT_EQ(tokens, expected);
}

TEST(ParserTest, SplitLineEmpty) {
  std::string const line = "     ";
  auto tokens            = parser::split_line(line);

  EXPECT_TRUE(tokens.empty());
}

TEST(ParserTest, SplitLineMultipleSpaces) {
  std::string const line = "token1    token2  token3";
  auto tokens            = parser::split_line(line);

  std::vector<std::string> const expected = {"token1", "token2", "token3"};
  EXPECT_EQ(tokens, expected);
}

TEST(ParserTest, SplitLineNoSpaces) {
  std::string const line = "singleToken";
  auto tokens            = parser::split_line(line);

  std::vector<std::string> const expected = {"singleToken"};
  EXPECT_EQ(tokens, expected);
}

TEST(ParserTest, SplitLineLeadingTrailingSpaces) {
  std::string const line = "   leading and trailing   ";
  auto tokens            = parser::split_line(line);

  std::vector<std::string> const expected = {"leading", "and", "trailing"};
  EXPECT_EQ(tokens, expected);
}

TEST(ParserTest, IsBlankLineTrue) {
  std::string const line = "     \t   ";
  EXPECT_TRUE(parser::is_blank_line(line));
}

TEST(ParserTest, IsBlankLineFalse) {
  std::string const line = "  not blank  ";
  EXPECT_FALSE(parser::is_blank_line(line));
}

TEST(ParserTest, IsBlankLineEmpty) {
  std::string const line;
  EXPECT_TRUE(parser::is_blank_line(line));
}

TEST(ParserTest, IsBlankLineWithNewline) {
  std::string const line = "\n";
  EXPECT_TRUE(parser::is_blank_line(line));
}

TEST(ParserTest, IsBlankLineWithMixedWhitespace) {
  std::string const line = " \t \n \r ";
  EXPECT_TRUE(parser::is_blank_line(line));
}
