#include "../include/image.hpp"
#include "../include/vector.hpp"
#include <cmath>
#include <cstdio>
#include <gtest/gtest.h>
#include <random>

// Test material rng
TEST(ImageConfigTest, MaterialRNGInitialization) {
  imagec::imageConfig::init_material_rng(42);
  std::mt19937_64 & gen1 = imagec::imageConfig::get_material_gen();
  auto val1              = gen1();

  imagec::imageConfig::init_material_rng(42);
  std::mt19937_64 & gen2 = imagec::imageConfig::get_material_gen();
  auto val2              = gen2();

  EXPECT_EQ(val1, val2);
}

// Test Pov direction vectors
TEST(PovTest, DirectionVectors) {
  render::point const cam_pos(0, 0, -10);
  render::point const cam_target(0, 0, 0);
  render::vector const cam_north(0, 1, 0);
  double const fov = 90.0;
  imagec::Pov const pov(cam_pos, cam_target, cam_north, fov, 1'920, 1'080, 12'345);
  render::vector const dir_u     = pov.dirv_u();
  render::vector const dir_v     = pov.dirv_v();
  render::vector const focal_vec = pov.focal_vector().normalize();
  EXPECT_NEAR(dir_u.dot(focal_vec), 0.0, 1e-6);
  EXPECT_NEAR(dir_u.dot(cam_north), 0.0, 1e-6);
  EXPECT_NEAR(dir_v.dot(focal_vec), 0.0, 1e-6);
  EXPECT_NEAR(dir_v.dot(dir_u), 0.0, 1e-6);
}
