#include "vector.hpp"
#include <cmath>
#include <gtest/gtest.h>
#include <stdexcept>

TEST(test_vector, magnitude_zero) {
  render::vector const vec{0.0, 0.0, 0.0};
  EXPECT_EQ(vec.magnitude(), 0.0);
}

TEST(test_vector, magnitude_positive) {
  render::vector const vec{3.0, 4.0, 0.0};
  EXPECT_EQ(vec.magnitude(), 5.0);
}

// Test para magnitude negative no es necesario ya que la magnitud siempre es no negativa

// Test para normalize
TEST(test_vector, normalize_non_zero) {
  render::vector const vec{3.0, 0.0, 4.0};
  render::vector const norm = vec.normalize();
  double const mag          = norm.magnitude();
  EXPECT_NEAR(mag, 1.0, 1e-9);
}

TEST(test_vector, normalize_zero) {
  render::vector const vec{0.0, 0.0, 0.0};
  render::vector const norm = vec.normalize();
  EXPECT_EQ(norm.X(), 1.0);
  EXPECT_EQ(norm.Y(), 0.0);
  EXPECT_EQ(norm.Z(), 0.0);
}

TEST(test_vector, normalize_nan) {
  render::vector const vec{NAN, NAN, NAN};
  render::vector const norm = vec.normalize();
  EXPECT_EQ(norm.X(), 1.0);
  EXPECT_EQ(norm.Y(), 0.0);
  EXPECT_EQ(norm.Z(), 0.0);
}

TEST(test_vector, dot_product) {
  render::vector const a{1.0, 2.0, 3.0};
  render::vector const b{4.0, -5.0, 6.0};
  double const result = a.dot(b);
  EXPECT_EQ(result, 12.0);
}

TEST(test_vector, cross_product) {
  render::vector const a{1.0, 0.0, 0.0};
  render::vector const b{0.0, 1.0, 0.0};
  render::vector const result = a.cross(b);
  EXPECT_EQ(result.X(), 0.0);
  EXPECT_EQ(result.Y(), 0.0);
  EXPECT_EQ(result.Z(), 1.0);
}

TEST(test_vector, add_scalar) {
  render::vector const vec{1.0, 2.0, 3.0};
  render::vector const result = vec.add(5.0);
  EXPECT_EQ(result.X(), 6.0);
  EXPECT_EQ(result.Y(), 7.0);
  EXPECT_EQ(result.Z(), 8.0);
}

TEST(test_vector, vector_addition) {
  render::vector const a{1.0, 2.0, 3.0};
  render::vector const b{4.0, 5.0, 6.0};
  render::vector const result = a + b;
  EXPECT_EQ(result.X(), 5.0);
  EXPECT_EQ(result.Y(), 7.0);
  EXPECT_EQ(result.Z(), 9.0);
}

TEST(test_vector, vector_subtraction) {
  render::vector const a{4.0, 5.0, 6.0};
  render::vector const b{1.0, 2.0, 3.0};
  render::vector const result = a - b;
  EXPECT_EQ(result.X(), 3.0);
  EXPECT_EQ(result.Y(), 3.0);
  EXPECT_EQ(result.Z(), 3.0);
}

TEST(test_vector, vector_scalar_multiplication) {
  render::vector const vec{1.0, 2.0, 3.0};
  render::vector const result = vec * 3.0;
  EXPECT_EQ(result.X(), 3.0);
  EXPECT_EQ(result.Y(), 6.0);
  EXPECT_EQ(result.Z(), 9.0);
}

TEST(test_vector, vector_scalar_division) {
  render::vector const vec{3.0, 6.0, 9.0};
  render::vector const result = vec / 3.0;
  EXPECT_EQ(result.X(), 1.0);
  EXPECT_EQ(result.Y(), 2.0);
  EXPECT_EQ(result.Z(), 3.0);
}

// Test para división por cero
TEST(test_vector, vector_scalar_division_by_zero) {
  render::vector const vec{3.0, 6.0, 9.0};
  EXPECT_THROW(vec / 0.0, std::runtime_error);
}

TEST(test_vector, vector_from_points) {
  render::point const a{1.0, 2.0, 3.0};
  render::point const b{4.0, 5.0, 6.0};
  render::vector const result = render::vector::get_vector_from_points(a, b);
  EXPECT_EQ(result.X(), 3.0);
  EXPECT_EQ(result.Y(), 3.0);
  EXPECT_EQ(result.Z(), 3.0);
}

TEST(test_vector, point_vector_addition) {
  render::point const p{1.0, 2.0, 3.0};
  render::vector const v{4.0, 5.0, 6.0};
  render::point const result = p + v;
  EXPECT_EQ(result.X(), 5.0);
  EXPECT_EQ(result.Y(), 7.0);
  EXPECT_EQ(result.Z(), 9.0);
}

TEST(test_vector, vector_negation) {
  render::vector const vec{1.0, -2.0, 3.0};
  render::vector const result = -vec;
  EXPECT_EQ(result.X(), -1.0);
  EXPECT_EQ(result.Y(), 2.0);
  EXPECT_EQ(result.Z(), -3.0);
}

int main(int argc, char ** argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
