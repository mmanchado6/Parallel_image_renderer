#include "../include/material.hpp"
#include "../include/object.hpp"
#include "../include/scene.hpp"
#include <cmath>
#include <cstdio>
#include <gtest/gtest.h>
#include <stdexcept>
#include <string>
#include <vector>

// Test add material
TEST(SceneTest, AddMaterial) {
  render::scene scene;
  material::material const mat1("test_material", material::material::materialType::Metal,
                                {1.0, 0.0, 0.0, 45.0});
  scene.add_material(mat1);
  EXPECT_EQ(scene.all_materials().size(), 1);
  EXPECT_THROW(scene.add_material(mat1), std::invalid_argument);  // Duplicate, should throw
}

// Test add sphere with existing material
TEST(SceneTest, AddSphereWithExistingMaterial) {
  render::scene scene;
  material::material const mat1("test_material", material::material::materialType::Matte,
                                {1.0, 0.0, 0.0});
  scene.add_material(mat1);
  object::sphere const sph1(render::point(0, 0, 0), 1.0, mat1);
  EXPECT_NO_THROW(scene.add_sphere(sph1));  // Should succeed
}

// Test add sphere with non-existing material
TEST(SceneTest, AddSphereWithNonExistingMaterial) {
  render::scene scene;
  material::material const mat1("test_material", material::material::materialType::Matte,
                                {1.0, 0.0, 0.0});
  object::sphere const sph1(render::point(0, 0, 0), 1.0, mat1);
  EXPECT_THROW(scene.add_sphere(sph1), std::invalid_argument);  // Should throw
}

// Test add cylinder with existing material
TEST(SceneTest, AddCylinderWithExistingMaterial) {
  render::scene scene;
  material::material const mat1("metal", material::material::materialType::Metal,
                                {0.8, 0.8, 0.8, 0.1});
  scene.add_material(mat1);
  object::cylinder const cyl1(render::point(0, 0, 0), 3.0, render::vector(0, 1, 0), mat1);
  EXPECT_NO_THROW(scene.add_cylinder(cyl1));  // Should succeed
}

// Test add cylinder with non-existing material
TEST(SceneTest, AddCylinderWithNonExistingMaterial) {
  render::scene scene;
  material::material const mat1("metal", material::material::materialType::Metal,
                                {0.8, 0.8, 0.8, 0.1});
  object::cylinder const cyl1(render::point(0, 0, 0), 1.0, render::vector(0, 1, 0), mat1);
  EXPECT_THROW(scene.add_cylinder(cyl1), std::invalid_argument);  // Should throw
}

// Test retrieve material
TEST(SceneTest, RetrieveMaterial) {
  render::scene scene;
  material::material const mat1("glass", material::material::materialType::Refractive, {1.5});
  scene.add_material(mat1);
  material::material const * retrieved = scene.material("glass");
  ASSERT_NE(retrieved, nullptr);
  EXPECT_EQ(retrieved->name(), "glass");
  EXPECT_EQ(retrieved->type(), material::material::materialType::Refractive);
}

// Test scene queries
TEST(SceneTest, SceneQueries) {
  render::scene scene;
  EXPECT_TRUE(scene.empty());
  material::material const mat1("matte", material::material::materialType::Matte, {0.5, 0.5, 0.5});
  scene.add_material(mat1);
  object::sphere const sph1(render::point(0, 0, 0), 1.0, mat1);
  scene.add_sphere(sph1);
  EXPECT_FALSE(scene.empty());
  EXPECT_EQ(scene.total_objects(), 1);
  object::cylinder const cyl1(render::point(0, 0, 0), 2.0, render::vector(0, 1, 0), mat1);
  scene.add_cylinder(cyl1);
  EXPECT_EQ(scene.total_objects(), 2);
}

// Test getters of scene
TEST(SceneTest, SceneGetters) {
  render::scene scene;

  material::material const mat1("matte", material::material::materialType::Matte, {0.5, 0.5, 0.5});
  scene.add_material(mat1);

  object::sphere const sph1(render::point(1, 2, 3), 1.0, mat1);
  scene.add_sphere(sph1);

  object::cylinder const cyl1(render::point(4, 5, 6), 2.0, render::vector(0, 1, 0), mat1);
  scene.add_cylinder(cyl1);

  auto const & spheres = scene.spheres();
  ASSERT_EQ(spheres.size(), 1);

  auto const pos_sphere = spheres[0].position();
  EXPECT_DOUBLE_EQ(pos_sphere.X(), 1.0);
  EXPECT_DOUBLE_EQ(pos_sphere.Y(), 2.0);
  EXPECT_DOUBLE_EQ(pos_sphere.Z(), 3.0);
  EXPECT_DOUBLE_EQ(spheres[0].radius(), 1.0);

  auto const & cylinders = scene.cylinders();
  ASSERT_EQ(cylinders.size(), 1);

  auto const pos_cyl = cylinders[0].position();
  EXPECT_DOUBLE_EQ(pos_cyl.X(), 4.0);
  EXPECT_DOUBLE_EQ(pos_cyl.Y(), 5.0);
  EXPECT_DOUBLE_EQ(pos_cyl.Z(), 6.0);
  EXPECT_DOUBLE_EQ(cylinders[0].radius(), 2.0);
}
