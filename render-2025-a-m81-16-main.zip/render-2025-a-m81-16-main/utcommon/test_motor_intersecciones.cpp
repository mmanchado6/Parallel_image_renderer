#include "../include/image.hpp"
#include "../include/interseccion.hpp"
#include "../include/material.hpp"
#include "../include/motor_intersecciones.hpp"
#include "../include/object.hpp"
#include "../include/ray.hpp"
#include "../include/scene.hpp"
#include "../include/vector.hpp"
#include <cmath>
#include <cstdio>
#include <gtest/gtest.h>
#include <vector>

// Test sphere intersection
TEST(ImageConfigTest, SphereIntersection) {
  render::point const ray_origin(0, 0, -5);
  render::vector const ray_direction(0, 0, 1);
  ray::ray const test_ray(ray_origin, ray_direction);

  render::point const sphere_center(0, 0, 0);
  double const sphere_radius = 1.0;
  material::material const mat("test_material", material::material::materialType::Matte,
                               {0.5, 0.5, 0.5});
  object::sphere const test_sphere(sphere_center, sphere_radius, mat);

  double const expected_lambda = 4.0;

  render::interseccion const intersection =
      render::motorIntersecciones::sphere_intersection(test_ray, test_sphere, expected_lambda);

  EXPECT_NEAR(intersection.distancia(), expected_lambda, 1e-6);
  EXPECT_NEAR(intersection.posicion().X(), 0.0, 1e-6);
  EXPECT_NEAR(intersection.posicion().Y(), 0.0, 1e-6);
  EXPECT_NEAR(intersection.posicion().Z(), -1.0, 1e-6);
  EXPECT_NEAR(intersection.normal().X(), 0.0, 1e-6);
  EXPECT_NEAR(intersection.normal().Y(), 0.0, 1e-6);
  EXPECT_NEAR(intersection.normal().Z(), -1.0, 1e-6);
}

// Test lateral cylinder intersection
TEST(ImageConfigTest, CylinderIntersection) {
  render::point const ray_origin(2, 0, 0);
  render::vector const ray_direction(-1, 0, 0);
  ray::ray const test_ray(ray_origin, ray_direction);

  render::point const cylinder_base(1, 0, 0);
  double const cylinder_radius = 1.0;
  render::vector const ax      = render::vector(0, 0, 2);
  material::material const mat("test_material", material::material::materialType::Matte,
                               {0.5, 0.5, 0.5});
  object::cylinder const test_cylinder(cylinder_base, cylinder_radius, ax, mat);

  double const expected_lambda = 1.0;

  render::interseccion const intersection =
      render::motorIntersecciones::lateral_cylinder_intersection(test_ray, test_cylinder,
                                                                 expected_lambda, ax.normalize());

  EXPECT_NEAR(intersection.distancia(), expected_lambda, 1e-6);
  EXPECT_NEAR(intersection.posicion().X(), 1.0, 1e-6);
  EXPECT_NEAR(intersection.posicion().Y(), 0.0, 1e-6);
  EXPECT_NEAR(intersection.posicion().Z(), 0.0, 1e-6);
  EXPECT_NEAR(intersection.normal().X(), 0.0, 1e-6);
  EXPECT_NEAR(intersection.normal().Y(), 0.0, 1e-6);
  EXPECT_NEAR(intersection.normal().Z(), 0.0, 1e-6);
}

// Test base cylinder intersection
TEST(ImageConfigTest, CylinderBaseIntersection) {
  render::point const ray_origin(0, 0, -1);
  render::vector const ray_direction(0, 0, 1);
  ray::ray const test_ray(ray_origin, ray_direction);
  render::point const cylinder_base(0, 0, 0);
  double const cylinder_radius         = 1.0;
  render::vector const cylinder_height = render::vector(0, 0, 2);
  material::material const mat("test_material", material::material::materialType::Matte,
                               {0.5, 0.5, 0.5});
  object::cylinder const test_cylinder(cylinder_base, cylinder_radius, cylinder_height, mat);

  double const expected_lambda = 1.0;

  render::interseccion const intersection = render::motorIntersecciones::base_cylinder_intersection(
      test_ray, test_cylinder, expected_lambda, render::vector(0, 0, -1));

  EXPECT_NEAR(intersection.distancia(), expected_lambda, 1e-6);
  EXPECT_NEAR(intersection.posicion().X(), 0.0, 1e-6);
  EXPECT_NEAR(intersection.posicion().Y(), 0.0, 1e-6);
  EXPECT_NEAR(intersection.posicion().Z(), 0.0, 1e-6);
  EXPECT_NEAR(intersection.normal().X(), 0.0, 1e-6);
  EXPECT_NEAR(intersection.normal().Y(), 0.0, 1e-6);
  EXPECT_NEAR(intersection.normal().Z(), -1.0, 1e-6);
}

// Test cylinder intersection comparison
TEST(ImageConfigTest, CylinderIntersectionComparison) {
  render::point const ray_origin(0.5, 0, -1);
  render::vector const ray_direction(0, 0, 1);
  ray::ray const test_ray(ray_origin, ray_direction);
  render::point const cylinder_base(0, 0, 0);
  double const cylinder_radius         = 1.0;
  render::vector const cylinder_height = render::vector(0, 0, 2);
  material::material const mat("test_material", material::material::materialType::Matte,
                               {0.5, 0.5, 0.5});
  object::cylinder const test_cylinder(cylinder_base, cylinder_radius, cylinder_height, mat);

  auto const intersection =
      render::motorIntersecciones::cylinder_intersection_comparison(test_ray, test_cylinder);
  if (intersection) {
    EXPECT_NEAR(intersection->distancia(), 2.0, 1e-6);
    EXPECT_NEAR(intersection->posicion().X(), 0.5, 1e-6);
    EXPECT_NEAR(intersection->posicion().Y(), 0.0, 1e-6);
    EXPECT_NEAR(intersection->posicion().Z(), 1.0, 1e-6);
    EXPECT_NEAR(intersection->normal().X(), 9.9999999999999995e-07, 1e-6);
    EXPECT_NEAR(intersection->normal().Y(), 0.0, 1e-6);
    EXPECT_NEAR(intersection->normal().Z(), -1.0, 1e-6);
  }
}

// Test find nearest intersection
TEST(ImageConfigTest, FindNearestIntersection) {
  render::point const ray_origin(0, 0, -5);
  render::vector const ray_direction(0, 0, 1);
  ray::ray const test_ray(ray_origin, ray_direction);
  material::material const mat1("material1", material::material::materialType::Matte,
                                {0.5, 0.5, 0.5});
  material::material const mat2("material2", material::material::materialType::Matte,
                                {0.5, 0.5, 0.5});
  object::sphere const test_sphere1(render::point(0, 0, 0), 1.0, mat1);
  object::sphere const test_sphere2(render::point(0, 0, 3), 1.0, mat2);
  render::scene test_scene;
  test_scene.add_material(mat1);
  test_scene.add_material(mat2);
  test_scene.add_sphere(test_sphere1);
  test_scene.add_sphere(test_sphere2);
  auto const intersection_opt =
      render::motorIntersecciones::find_nearest_intersection(test_ray, test_scene);
  ASSERT_TRUE(intersection_opt.has_value());
  if (intersection_opt) {
    EXPECT_NEAR(intersection_opt->distancia(), 4.0, 1e-6);
    EXPECT_NEAR(intersection_opt->posicion().X(), 0.0, 1e-6);
    EXPECT_NEAR(intersection_opt->posicion().Y(), 0.0, 1e-6);
    EXPECT_NEAR(intersection_opt->posicion().Z(), -1.0, 1e-6);
  }
}

// Test matte reflection ray vector
TEST(ImageConfigTest, MatteReflectionRayVector) {
  render::point const ray_origin(0, 0, -5);
  render::vector const ray_direction(0, 0, 1);
  ray::ray const test_ray(ray_origin, ray_direction);
  render::point const intersection_point(0, 0, -1);
  render::vector const intersection_normal(0, 0, -1);
  render::interseccion_params const params{
    intersection_point, intersection_normal, 4.0, true, test_ray, nullptr};
  render::interseccion const test_intersection(params);
  render::vector const reflected_vector =
      render::motorIntersecciones::matte_reflection_ray_vector(test_intersection);
  EXPECT_NEAR(reflected_vector.X(), 0.15270507633556527, 1e-6);
  EXPECT_NEAR(reflected_vector.Y(), 0.27694358130448182, 1e-6);
  EXPECT_NEAR(reflected_vector.Z(), -0.94867455559617342, 1e-6);
}

// Test mettal reflection ray vector
TEST(ImageConfigTest, MetalReflectionRayVector) {
  render::point const ray_origin(0, 0, -5);
  render::vector const ray_direction(0, 0, 1);
  ray::ray const test_ray(ray_origin, ray_direction);
  render::point const intersection_point(0, 0, -1);
  render::vector const intersection_normal(0, 0, -1);
  object::sphere const test_sphere(
      render::point(0, 0, 0), 1.0,
      material::material("test_material", material::material::materialType::Metal,
                         {0.5, 0.5, 0.5, 0.1}));
  render::interseccion_params const params{intersection_point, intersection_normal, 4.0, true,
                                           test_ray,           &test_sphere};
  render::interseccion const test_intersection(params);

  render::vector const reflected_vector =
      render::motorIntersecciones::metal_reflection_ray_vector(test_intersection);
  EXPECT_NEAR(reflected_vector.X(), 0.016157467233784598, 1e-6);
  EXPECT_NEAR(reflected_vector.Y(), -0.087954957811684178, 1e-6);
  EXPECT_NEAR(reflected_vector.Z(), -0.99599340442039785, 1e-6);
}

// Test refractive reflection ray vector
TEST(ImageConfigTest, RefractiveReflectionRayVector) {
  render::point const ray_origin(0, 0, -5);
  render::vector const ray_direction(0, 0, 1);
  ray::ray const test_ray(ray_origin, ray_direction);
  render::point const intersection_point(0, 0, -1);
  render::vector const intersection_normal(0, 0, -1);
  object::sphere const test_sphere(
      render::point(0, 0, 0), 1.0,
      material::material("test_material", material::material::materialType::Refractive, {1.5}));
  render::interseccion_params const params{intersection_point, intersection_normal, 4.0, true,
                                           test_ray,           &test_sphere};
  render::interseccion const test_intersection(params);
  render::vector const refracted_vector =
      render::motorIntersecciones::refractive_reflection_ray_vector(test_intersection);
  EXPECT_NEAR(refracted_vector.X(), 0.0, 1e-6);
  EXPECT_NEAR(refracted_vector.Y(), 0.0, 1e-6);
  EXPECT_NEAR(refracted_vector.Z(), 1.0, 1e-6);
}

// Test reflected direction
TEST(ImageConfigTest, ReflectedDirection) {
  render::point const ray_origin(0, 0, -5);
  render::vector const ray_direction(0, 0, 1);
  ray::ray const test_ray(ray_origin, ray_direction);
  render::point const intersection_point(0, 0, -1);
  render::vector const intersection_normal(0, 0, -1);
  object::sphere const test_sphere(
      render::point(0, 0, 0), 1.0,
      material::material("test_material", material::material::materialType::Refractive, {1.5}));
  render::interseccion_params const params{intersection_point, intersection_normal, 4.0, true,
                                           test_ray,           &test_sphere};
  render::interseccion const test_intersection(params);
  render::vector const reflected_vector =
      render::motorIntersecciones::reflected_dir(test_intersection);
  EXPECT_NEAR(reflected_vector.X(), 0.0, 1e-6);
  EXPECT_NEAR(reflected_vector.Y(), 0.0, 1e-6);
  EXPECT_NEAR(reflected_vector.Z(), 1.0, 1e-6);
}

// Test trace child ray
TEST(ImageConfigTest, TraceChildRay) {
  render::point const ray_origin(0, 0, -5);
  render::vector const ray_direction(0, 0, 1);
  ray::ray const test_ray(ray_origin, ray_direction);
  render::point const intersection_point(0, 0, -1);
  render::vector const intersection_normal(0, 0, -1);
  object::sphere const test_sphere(
      render::point(0, 0, 0), 1.0,
      material::material("test_material", material::material::materialType::Matte,
                         {0.5, 0.5, 0.5}));
  render::interseccion_params const params{intersection_point, intersection_normal, 4.0, true,
                                           test_ray,           &test_sphere};
  render::interseccion const test_intersection(params);
  render::scene test_scene;
  test_scene.add_material(test_sphere.material());
  test_scene.add_sphere(test_sphere);
  render::interseccion_params const inter_params{intersection_point, intersection_normal, 4.0, true,
                                                 test_ray,           &test_sphere};
  render::interseccion const test_interseccion(inter_params);

  imagec::imageConfig const test_config;
  imagec::Color const traced_color =
      render::motorIntersecciones::trace_child_ray(test_ray, 5, test_scene, test_config);
  // Dado que no hay luces ni otras intersecciones, el color debería ser el color de fondo
  EXPECT_NEAR(std::get<0>(traced_color), 0.37648668522059403, 1e-6);
  EXPECT_NEAR(std::get<1>(traced_color), 0.41765779014706267, 1e-6);
  EXPECT_NEAR(std::get<2>(traced_color), 0.5, 1e-6);
}

// Test color contribution
TEST(ImageConfigTest, ColorContribution) {
  render::point const ray_origin(0, 0, -5);
  render::vector const ray_direction(0, 0, 1);
  ray::ray const test_ray(ray_origin, ray_direction);
  render::point const intersection_point(0, 0, -1);
  render::vector const intersection_normal(0, 0, -1);
  object::sphere const test_sphere(
      render::point(0, 0, 0), 1.0,
      material::material("test_material", material::material::materialType::Matte,
                         {0.5, 0.5, 0.5}));
  render::interseccion_params const params{intersection_point, intersection_normal, 4.0, true,
                                           test_ray,           &test_sphere};
  render::interseccion const test_intersection(params);
  render::scene test_scene;
  test_scene.add_material(test_sphere.material());
  test_scene.add_sphere(test_sphere);
  render::interseccion_params const inter_params{intersection_point, intersection_normal, 4.0, true,
                                                 test_ray,           &test_sphere};
  render::interseccion const test_interseccion(inter_params);

  imagec::imageConfig const test_config;
  imagec::Color const traced_color =
      render::motorIntersecciones::trace_child_ray(test_ray, 5, test_scene, test_config);
  // Dado que no hay luces ni otras intersecciones, el color debería ser el color de fondo
  EXPECT_NEAR(std::get<0>(traced_color), 0.30, 5e-2);
  EXPECT_NEAR(std::get<1>(traced_color), 0.41, 5e-2);
  EXPECT_NEAR(std::get<2>(traced_color), 0.5, 5e-2);
}

// Test color contribution
TEST(ImageConfigTest, BackgroundColor) {
  render::point const ray_origin(0, 0, -5);
  render::vector const ray_direction(0, 0, 1);
  ray::ray const test_ray(ray_origin, ray_direction);

  imagec::imageConfig const test_config;
  imagec::Color const background_color =
      render::motorIntersecciones::background_color(test_ray, test_config);

  EXPECT_NEAR(std::get<0>(background_color), 0.625, 1e-6);
  EXPECT_NEAR(std::get<1>(background_color), 0.750, 1e-6);
  EXPECT_NEAR(std::get<2>(background_color), 1.000, 1e-6);
}
