#include "material.hpp"
#include "object.hpp"

#include "ray.hpp"
#include "vector.hpp"
#include <cmath>
#include <gtest/gtest.h>
#include <vector>

TEST(test_object, constructor) {
  material::material const mat("test_material", material::material::materialType::Matte,
                               {0.5, 0.5, 0.5});
  render::point const pos{0.0, 0.0, 0.0};
  object::sphere const obj(pos, 1.0, mat);
  EXPECT_EQ(obj.position().X(), 0.0);
  EXPECT_EQ(obj.position().Y(), 0.0);
  EXPECT_EQ(obj.position().Z(), 0.0);
  EXPECT_EQ(obj.radius(), 1.0);
  EXPECT_EQ(obj.material().name(), mat.name());
}

// Test para compute_params en sphere

TEST(test_object, calculate_lambda_no_intersection) {
  double const a      = 1.0;
  double const b      = 0.0;
  double const c      = 1.0;
  double const lambda = object::object::calculate_lambda(a, b, c);
  EXPECT_EQ(lambda, -1.0);  // No hay intersección
}

TEST(test_object, calculate_lambda_two_intersections) {
  double const a      = 1.0;
  double const b      = -3.0;
  double const c      = 2.0;
  double const lambda = object::object::calculate_lambda(a, b, c);
  EXPECT_EQ(lambda, 1.0);  // La intersección más cercana positiva
}

TEST(test_object, calculate_lambda_one_intersection) {
  double const a      = 1.0;
  double const b      = 2.0;
  double const c      = 1.0;
  double const lambda = object::object::calculate_lambda(a, b, c);
  EXPECT_EQ(lambda, -1.0);  // La única intersección es negativa
}

TEST(test_object, calculate_lambda_degenerate_case) {
  double const a      = 0.0;
  double const b      = 0.0;
  double const c      = 1.0;
  double const lambda = object::object::calculate_lambda(a, b, c);
  EXPECT_EQ(lambda, -1.0);  // Caso degenerado
}

// Test getter normal en sphere
TEST(test_object, sphere_normal) {
  material::material const mat("test_material", material::material::materialType::Metal,
                               {0.5, 0.5, 0.5, 0.1});
  render::point const pos{0.0, 0.0, 0.0};
  object::sphere const sph(pos, 1.0, mat);
  render::point const ipoint{1.0, 0.0, 0.0};
  render::vector const normal = sph.normal(ipoint);
  EXPECT_NEAR(normal.X(), 1.0, 1e-9);
  EXPECT_NEAR(normal.Y(), 0.0, 1e-9);
  EXPECT_NEAR(normal.Z(), 0.0, 1e-9);
}

// Test para compute_params en cylinder

TEST(test_object, cylinder_compute_params) {
  material::material const mat("test_material", material::material::materialType::Refractive,
                               {0.5});
  render::point const pos{0.0, 0.0, 0.0};
  render::vector const axis{0.0, 1.0, 0.0};
  object::cylinder const cyl(pos, 1.0, axis, mat);

  render::point const ray_origin{2.0, 1.0, 0.0};
  render::vector const ray_direction{-1.0, 0.0, 0.0};
  ray::ray const rayo(ray_origin, ray_direction);

  auto [a, b, c] = cyl.compute_params(rayo);
  EXPECT_NEAR(a, 1.0, 1e-9);
  EXPECT_NEAR(b, -4.0, 1e-9);
  EXPECT_NEAR(c, 3.0, 1e-9);
}

// Test getter normal en cylinder
TEST(test_object, cylinder_normal) {
  material::material const mat("test_material", material::material::materialType::Matte,
                               {0.5, 0.5, 0.5});
  render::point const pos{0.0, 0.0, 0.0};
  render::vector const axis{0.0, 1.0, 0.0};
  object::cylinder const cyl(pos, 1.0, axis, mat);

  render::point const ipoint{1.0, 0.0, 0.0};
  render::vector const normal = cyl.normal(ipoint);

  EXPECT_NEAR(normal.X(), 1.0, 1e-9);
  EXPECT_NEAR(normal.Y(), 0.0, 1e-9);
  EXPECT_NEAR(normal.Z(), 0.0, 1e-9);
}
