#ifndef IMAGE_REP_HPP
#define IMAGE_REP_HPP

#include <string>
#include <vector>

namespace image {

  class imageSOA {
  public:
    imageSOA(int width, int height)
        : red_array_(static_cast<size_t>(width * height), 0),
          green_array_(static_cast<size_t>(width * height), 0),
          blue_array_(static_cast<size_t>(width * height), 0), width_(width), height_(height) { }

    // Getters para los diferentes colores
    [[nodiscard]] int red(int row, int col) const;
    [[nodiscard]] int green(int row, int col) const;
    [[nodiscard]] int blue(int row, int col) const;

    // Setters para los diferentes colores
    void setRed(int row, int col, int value);
    void setGreen(int row, int col, int value);
    void setBlue(int row, int col, int value);

    void setPixel(int row, int col, std::tuple<int, int, int> const & rgb);

    // Generar salida ppm
    void write_ppm(std::string const & filename) const;

    // Obtener las dimensiones de la imagen
    [[nodiscard]] int width() const { return width_; }

    [[nodiscard]] int height() const { return height_; }

  private:
    std::vector<int> red_array_;
    std::vector<int> green_array_;
    std::vector<int> blue_array_;
    int width_, height_;
  };

}  // namespace image

#endif
