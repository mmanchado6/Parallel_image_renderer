#include <cstddef>
#include <fstream>
#include <stdexcept>
#include <string>
#include <tuple>

#include "../include/image_soa.hpp"

namespace image {

  int imageSOA::red(int row, int col) const {
    return red_array_[static_cast<size_t>(row) * static_cast<size_t>(width_) +
                      static_cast<size_t>(col)];
  }

  int imageSOA::green(int row, int col) const {
    return green_array_[static_cast<size_t>(row) * static_cast<size_t>(width_) +
                        static_cast<size_t>(col)];
  }

  int imageSOA::blue(int row, int col) const {
    return blue_array_[static_cast<size_t>(row) * static_cast<size_t>(width_) +
                       static_cast<size_t>(col)];
  }

  void imageSOA::setRed(int row, int col, int value) {
    red_array_[static_cast<size_t>(row) * static_cast<size_t>(width_) + static_cast<size_t>(col)] =
        value;
  }

  void imageSOA::setGreen(int row, int col, int value) {
    green_array_[static_cast<size_t>(row) * static_cast<size_t>(width_) +
                 static_cast<size_t>(col)] = value;
  }

  void imageSOA::setBlue(int row, int col, int value) {
    blue_array_[static_cast<size_t>(row) * static_cast<size_t>(width_) + static_cast<size_t>(col)] =
        value;
  }

  void imageSOA::setPixel(int row, int col, std::tuple<int, int, int> const & rgb) {
    setRed(row, col, std::get<0>(rgb));
    setGreen(row, col, std::get<1>(rgb));
    setBlue(row, col, std::get<2>(rgb));
  }

  void imageSOA::write_ppm(std::string const & filename) const {
    std::ofstream file;
    file.open(filename);
    if (!file) {
      throw std::runtime_error("No se pudo abrir el archivo");
    }

    // Escribir el encabezado del PPM
    file << "P3\n" << width_ << " " << height_ << "\n255\n";

    // Escribir los píxeles
    for (int y = 0; y < height_; ++y) {
      for (int x = 0; x < width_; ++x) {
        file << red(y, x) << " " << green(y, x) << " " << blue(y, x) << "\n";
      }
    }

    file.close();
  }

}  // namespace image
