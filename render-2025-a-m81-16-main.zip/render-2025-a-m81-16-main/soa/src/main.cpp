#include "image.hpp"
#include <random>
#include <span>
#include <string>
#include <vector>

#include "../../common/include/configuration_parser.hpp"
#include "../../common/include/motor_intersecciones.hpp"
#include "../../common/include/scene_parser.hpp"
#include "../include/image_soa.hpp"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <exception>
#include <tuple>
#include <utility>

#include "ray.hpp"
#include "scene.hpp"
#include "vector.hpp"

namespace {

  struct Config {
    std::string config_file;
    std::string scene_file;
    std::string output_file;
  };

  struct RenderingContext {
    image::imageSOA image;
    imagec::Pov viewpoint;
    render::scene scene;
    imagec::imageConfig config;
  };

  Config parse_arguments(std::span<char *> args) {
    if (args.size() != 4) {
      std::exit(1);
    }

    return {std::string(args[1]), std::string(args[2]), std::string(args[3])};
  }

  RenderingContext initialize_rendering(Config const & cfg) {
    // Función utilizada para obtener todo lo relacionado con la configuración de la imagen
    imagec::imageConfig config = configurationParser::parse(cfg.config_file);
    render::scene scene        = sceneParser::parse(cfg.scene_file);

    int const image_width  = config.width();
    int const image_height = config.height();
    image::imageSOA image(image_width, image_height);

    auto [cam_pos, cam_target, cam_north, fov] = config.paramsView();

    imagec::Pov const viewpoint(cam_pos, cam_target, cam_north, static_cast<double>(fov),
                                image_width, image_height,
                                static_cast<std::uint_fast64_t>(config.ray_seed()));

    return {std::move(image), viewpoint, std::move(scene), std::move(config)};
  }

  struct PixelComputationParams {
    // Calculo de pixeles
    render::point O{
      0,
      0,
      0,
    };
    render::vector delta_x{0, 0, 0};
    render::vector delta_y{0, 0, 0};
    int row{};
    int col{};
    RenderingContext const * ctx{};
    double offset_x{};
    double offset_y{};
    std::uniform_real_distribution<double> * dist{};
  };

  std::tuple<int, int, int> apply_post_processing(double r, double g, double b,
                                                  RenderingContext const & ctx) {
    // Aplicar el postprocesado a los colores
    double const inv_samples = 1.0 / static_cast<double>(ctx.config.samples_per_pixel());

    r *= inv_samples;
    g *= inv_samples;
    b *= inv_samples;

    double const gamma_inv = 1.0 / ctx.config.gamma();

    r = std::pow(r, gamma_inv);
    g = std::pow(g, gamma_inv);
    b = std::pow(b, gamma_inv);

    double r_scaled = r * 255.0;
    double g_scaled = g * 255.0;
    double b_scaled = b * 255.0;

    // Clampear
    r_scaled = std::clamp(r_scaled, 0.0, 255.0);
    g_scaled = std::clamp(g_scaled, 0.0, 255.0);
    b_scaled = std::clamp(b_scaled, 0.0, 255.0);

    return {static_cast<int>(r_scaled), static_cast<int>(g_scaled), static_cast<int>(b_scaled)};
  }

  struct RenderParams {
    render::point O{0, 0, 0};
    render::vector delta_x{0, 0, 0};
    render::vector delta_y{0, 0, 0};
    render::point cam_pos{0, 0, 0};
    render::scene const * scene        = nullptr;
    imagec::imageConfig const * config = nullptr;
    int samples                        = 0;
  };

  struct OffsetData {
    std::vector<double> const * offsets_x = nullptr;
    std::vector<double> const * offsets_y = nullptr;
    size_t * offset_index                 = nullptr;
  };

  // Pre-generar offsets
  std::pair<std::vector<double>, std::vector<double>> pregenerate_offsets(int total_samples,
                                                                          std::mt19937_64 & rng) {
    std::vector<double> offsets_x, offsets_y;
    offsets_x.reserve(static_cast<size_t>(total_samples));
    offsets_y.reserve(static_cast<size_t>(total_samples));

    std::uniform_real_distribution<double> pixel_dist(-0.5, 0.5);

    for (int i = 0; i < total_samples; ++i) {
      offsets_x.push_back(pixel_dist(rng));
      offsets_y.push_back(pixel_dist(rng));
    }

    return {std::move(offsets_x), std::move(offsets_y)};
  }

  // Renderizar imagen principal
  void render_image(RenderingContext & ctx) {
    RenderParams const params{ctx.viewpoint.origin_proj_win(),
                              ctx.viewpoint.displacement_x(),
                              ctx.viewpoint.displacement_y(),
                              ctx.viewpoint.position(),
                              &ctx.scene,
                              &ctx.config,
                              ctx.config.samples_per_pixel()};
    int const height = ctx.image.height(), width = ctx.image.width();
    int const BLOCK_SIZE = 32, SAMPLES = params.samples;
    std::mt19937_64 ray_rng(ctx.viewpoint.seed());
    auto [offsets_x, offsets_y] = pregenerate_offsets(width * height * SAMPLES, ray_rng);
    size_t offset_index         = 0;
    for (int block_row = 0; block_row < height; block_row += BLOCK_SIZE) {
      int const block_h = std::min(BLOCK_SIZE, height - block_row);
      for (int block_col = 0; block_col < width; block_col += BLOCK_SIZE) {
        int const block_w = std::min(BLOCK_SIZE, width - block_col);
        for (int row = block_row; row < block_row + block_h; ++row) {
          for (int col = block_col; col < block_col + block_w; ++col) {
            double r = 0.0, g = 0.0, b = 0.0;
            for (int s = 0; s < SAMPLES; ++s) {
              double const ox = offsets_x[offset_index], oy = offsets_y[offset_index++];
              render::point const Q =
                  params.O + params.delta_x * (col + ox) + params.delta_y * (row + oy);
              ray::ray const ray(params.cam_pos,
                                 render::vector::get_vector_from_points(params.cam_pos, Q));
              auto hit = render::motorIntersecciones::find_nearest_intersection(ray, *params.scene);
              auto color =
                  hit ? render::motorIntersecciones::color_contribution(
                            hit.value(), params.config->max_depth(), *params.scene, *params.config)
                      : render::motorIntersecciones::background_color(ray, *params.config);
              r += std::get<0>(color);
              g += std::get<1>(color);
              b += std::get<2>(color);
            }
            ctx.image.setPixel(row, col, apply_post_processing(r, g, b, ctx));
          }
        }
      }
    }
  }

}  // namespace

int main(int argc, char * argv[]) {
  try {
    // Parseamos los archivos de entrada
    Config const config = parse_arguments(std::span(argv, static_cast<size_t>(argc)));

    // Configuramos todos los párametros
    RenderingContext ctx = initialize_rendering(config);

    // Iniciamos el rng
    imagec::imageConfig::init_material_rng(
        static_cast<std::uint_fast64_t>(ctx.config.material_seed()));

    // Renderizamos la imagen
    render_image(ctx);

    // Escribimos en el archivo de salida
    ctx.image.write_ppm(config.output_file);

  } catch (std::exception const & e) {
    return 1;
  }

  return 0;
}
